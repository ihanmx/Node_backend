const fs = require("fs");

const requestHandeler = (req, res) => {
  const url = req.url;
  const method = req.method;

  if (url === "/") {
    res.setHeader("Content-Type", "text/html");
    res.write("<html>");
    res.write("<head><title>my app</title></head>");
    res.write(
      '<form action="/message" method="POST" > <input name="username" /><Button type="submit">submit</Button> </form>'
    );

    res.write("</html>");
    return res.end();
  }

  if (url === "/message" && method === "POST") {
    // body parsing to get data from streaming operation
    const body = [];
    req.on("data", (chunck) => {
      //data arrives as a chuncks could be one or more
      console.log(chunck);
      body.push(chunck);
    }); //event listener when we are going to receive data and call back function

    return req.on("end", () => {
      //return blocks tthe code down because of async
      const parsedBody = Buffer.concat(body).toString();
      console.log(parsedBody);
      const message = parsedBody.split("=")[1]; //because form sends the data as key value pairs we split = the pait [0]key [1] value like:name="khalid"
      //   fs.writeFileSync("message.txt", message); //Sync is a special func that blocks excution untill it done so better
      fs.writeFile("message.txt", message, (err) => {
        res.statusCode = 302; //this code indicate redirection
        res.setHeader("location", "/"); //destination of redirection
        //    console.log(err);
        return res.end();
      });
    }); //when data streaming chucnk are ready we store them in buffers as bus stop to handle them safely throughout the code
  }
};

module.exports = requestHandeler;

// other ways to export
// module.exports = { handler: requestHandeler, someText: "test" };

// module,exports.handler= requestHandeler;
// module,exports.someText= "test";

// for multiple export only
// exports.handler= requestHandeler;
// exports.someText= "test";
