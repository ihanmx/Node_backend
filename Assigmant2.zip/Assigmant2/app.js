const express = require("express");

const app = express();

app.use("/users", (req, res, next) => {
  console.log("userspage");
  res.send("<h1>Hello from page2</h1>");
});

// should be down to not excuate always
app.use("/", (req, res, next) => {
  console.log("middleware /");
  res.send("<h1>Hello from home</h1>");
});

// app .use middlewares always applied from top to buttom in order

// app.use((req, res, next) => {
//   console.log("hello from middleware 1");
//   next();
// });

// app.use((req, res, next) => {
//   console.log("hello from middleware 2");
//   res.send("<h1>Hello </h1>");
// });
//app.use is method that allows me to create middlewears acts like layers that app go throw
// next is function i should call to move to next block
//if we send a res you won't be able to mive to next block so res==no need for next

app.listen(3000);
