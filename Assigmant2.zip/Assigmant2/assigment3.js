const express = require("express");
const bodyParser = require("body-parser");
const adminRoutes = require("../NodeBasics/routes/admin.js");
const shopRouter = require("../NodeBasics/routes/shop.js");

const app = express();

app.use(bodyParser.urlencoded({ extended: false }));

app.use("/admin", adminRoutes); ///admin is shared path to all routes
app.use("/shop", shopRouter); //order doesnt matter because we used get and post in routes instead of use but still it is good to order

app.use((req, res, next) => {
  res.status(404).send("<h1>page not found</h1>");
}); //use handles all orders +to send error when access unsupported url

// app.use("/add-product", (req, res, next) => {
//   res.send(
//     '<form action=/product method="POST"><input type="text" name="product"></input> <button type="submit">submit</button></form> '
//   );
// });

// app.post("/product", (req, res, next) => {
//   console.log(req.body);
//   res.redirect("/");
// });

// app.use("/users", (req, res, next) => {
//   console.log("userspage");
//   res.send("<h1>Hello from page2</h1>");
// });

// should be down to not excuate always

app.listen(3000);
