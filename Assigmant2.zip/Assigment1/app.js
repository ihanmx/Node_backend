const http = require("http");
const fs = require("fs");

const server = http.createServer((req, res) => {
  const url = req.url;
  const method = req.method;

  if (url === "/") {
    res.setHeader("Content-Type", "text/html");
    res.write("<html>");
    res.write("<head><title>my app</title></head>");
    res.write("<h1> welcome to my server </h1>");

    res.write("    <ul>users");
    res.write("    <li>user1</li>");
    res.write("    <li>user2</li>");
    res.write("    </ul>");

    res.write(
      '<form action="/create-user" method="POST" > <input name="username" /><Button type="submit">submit</Button> </form>'
    );

    res.write("</html>");

    return res.end();
  }

  if (url === "/create-user" && method == "POST") {
    const body = [];
    req.on("data", (chunck) => {
      body.push(chunck);
      console.log(body);
    });

    return req.on("end", () => {
      const parsedBody = Buffer.concat(body).toString();
      const user = parsedBody.split("=")[1];
      fs.writeFile("user.txt", user, (err) => {
        res.statusCode = 302;
        res.setHeader("Location", "/");
        return res.end();
      });
    });
  }
});

server.listen(3000);
