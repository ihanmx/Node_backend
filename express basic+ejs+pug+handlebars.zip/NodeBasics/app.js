const express = require("express");
const bodyParser = require("body-parser");
const adminData = require("./routes/admin.js");
const shopRouter = require("./routes/shop.js");
const path = require("path");

const { engine } = require("express-handlebars"); // <-- important for v7+
// removed express-handlebars: this project contains Pug templates

const app = express();

app.set("view engine", "ejs");
app.set("views", "views"); // optional: default is 'views'

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "public"))); //to read the path of static folders like CSS

app.use("/admin", adminData.routes); ///admin is shared path to all routes
app.use(shopRouter); //order doesnt matter because we used get and post in routes instead of use but still it is good to order

app.use((req, res, next) => {
  res.status(404).render("404", { pageTitle: "Page not found" });
});

app.listen(3000, () => {
  console.log("Server listening on http://localhost:3000");
});
