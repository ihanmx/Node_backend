const path = require("path");

//or
module.exports = path.dirname(require.main.filename);
