const express = require("express");
const path = require("path");
const rootDir = require("../helper/path");

const router = express.Router();
const products = [];

router.get("/add-product", (req, res, next) => {
  // res.sendFile(path.join(rootDir, "views", "add-products.html")); //you can use .. or /..

  res.render("add-product", {
    pageTitle: "Add product",
    path: "/admin/add-product",
    formCss: true,
    productCss: true,
    activeAddProduct: true,
  });
});

router.post("/add-product", (req, res, next) => {
  products.push({ title: req.body.title });
  console.log(req.body);
  res.redirect("/");
});

//note: i can use exactly the same path if it is on diffierent methods POST or GET or so on

exports.routes = router;
exports.products = products;
