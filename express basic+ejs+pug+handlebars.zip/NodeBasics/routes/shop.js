const express = require("express");
const path = require("path");

const rootDir = require("../helper/path");
const adminData = require("./admin.js");

const router = express.Router();

router.get("/", (req, res, next) => {
  const products = adminData.products;

  res.render("shop", {
    prods: products,
    pageTitle: "Shop",
    path: "/",
    hasProducts: products.length > 0,
    activeShop: true,
    productCss: true,
    activeShop: true,
  });

  //when we sendFile we need to use absulute path of machine so path.join make it available by global variable __dirname(current folder)

  // console.log(adminData.products);

  //  res.sendFile(path.join(rootDir, "views", "shop.html"));

  // res.sendFile(path.join(__dirname,'..', "views", "shop.html")); //avoid using comma .join will concat for you to work on both lynix and widows (../ goes up one level because dirname is current routes folder)
});

module.exports = router;
